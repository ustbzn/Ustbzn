        """
        # from 0 to turn 
        elif 5 <= t2 - t1 <= 180:
            ROS_VCU_PctSteer = steering_value
            ROS_VCU_SteerFreq = abs(int(SteerFreq))
            ROS_VCU_flgSteerEnable = 0
            if SteerFreq >= 0:
                ROS_VCU_flgSteerDirection = 0
            else:
                ROS_VCU_flgSteerDirection = 1
        """
	
	"""
        # sin
        elif 7 <= t2 - t1 < 90:
            ROS_VCU_PctSteer = steering_value
            steer1 = 2000 * math.sin(math.pi * (t2 - t1 - 7) / 6)
            ROS_VCU_SteerFreq = abs(int(steer1))
            ROS_VCU_flgSteerEnable = 0
            if steer1 >= 0:
                ROS_VCU_flgSteerDirection = 0
            else:
                ROS_VCU_flgSteerDirection = 1
	"""
	
        """
        # step
        elif 7 <= t2 - t1 < 7 + dt:
            ROS_VCU_PctSteer = 50
            ROS_VCU_SteerFreq = 500
            ROS_VCU_flgSteerEnable = 0
            ROS_VCU_flgSteerDirection = 0
        elif 7 + dt <= t2 - t1 < 7 + 2 * dt:
            ROS_VCU_PctSteer = 50
            ROS_VCU_SteerFreq = 1000
            ROS_VCU_flgSteerEnable = 0
            ROS_VCU_flgSteerDirection = 0
        elif 7 + 2 * dt <= t2 - t1 < 7 + 3 * dt:
            ROS_VCU_PctSteer = 50
            ROS_VCU_SteerFreq = 1500
            ROS_VCU_flgSteerEnable = 0
            ROS_VCU_flgSteerDirection = 0
        elif 7 + 3 * dt <= t2 - t1 < 7 + 4 * dt:
            ROS_VCU_PctSteer = 50
            ROS_VCU_SteerFreq = 2000
            ROS_VCU_flgSteerEnable = 0
            ROS_VCU_flgSteerDirection = 0
        elif 7 + 4 * dt <= t2 - t1 < 7 + 5 * dt:
            ROS_VCU_PctSteer = 50
            ROS_VCU_SteerFreq = 2000
            ROS_VCU_flgSteerEnable = 0
            ROS_VCU_flgSteerDirection = 1
        elif 7 + 5 * dt <= t2 - t1 < 7 + 6 * dt:
            ROS_VCU_PctSteer = 50
            ROS_VCU_SteerFreq = 1500
            ROS_VCU_flgSteerEnable = 0
            ROS_VCU_flgSteerDirection = 1
        elif 7 + 6 * dt <= t2 - t1 < 7 + 7 * dt:
            ROS_VCU_PctSteer = 50
            ROS_VCU_SteerFreq = 1000
            ROS_VCU_flgSteerEnable = 0
            ROS_VCU_flgSteerDirection = 1
        elif 7 + 7 * dt <= t2 - t1:
            ROS_VCU_PctSteer = 50
            ROS_VCU_SteerFreq = 500
            ROS_VCU_flgSteerEnable = 0
            ROS_VCU_flgSteerDirection = 1
        """
        """
        # ramp
        elif 5 <= t2 - t1 < 5 + dtR:
            ROS_VCU_PctSteer = 50
            steer1 = 2000 / dtR * (t2 - t1 - 5) 
            ROS_VCU_SteerFreq = abs(int(steer1))
            ROS_VCU_flgSteerEnable = 0
            ROS_VCU_flgSteerDirection = 0
        elif 5 + dtR <= t2 - t1 < 5 + 3 * dtR:
            ROS_VCU_PctSteer = 50
            steer1 = (2000 - (2000 / dtR) * (t2 - t1 - 5 - dtR) )
            ROS_VCU_SteerFreq = abs(int(steer1))
            ROS_VCU_flgSteerEnable = 0
            if steer1 >= 0:
                ROS_VCU_flgSteerDirection = 0
            else:
                ROS_VCU_flgSteerDirection = 1
        elif 5 + 3 * dtR <= t2 - t1 < 5 + 4 * dtR:
            ROS_VCU_PctSteer = 50
            steer1 = (- 2000 + (2000 / dtR) * (t2 - t1 - 5 - 3 * dtR))
            ROS_VCU_SteerFreq = abs(int(steer1))
            ROS_VCU_flgSteerEnable = 0
            if steer1 >= 0:
                ROS_VCU_flgSteerDirection = 0
            else:
                ROS_VCU_flgSteerDirection = 1
        """
