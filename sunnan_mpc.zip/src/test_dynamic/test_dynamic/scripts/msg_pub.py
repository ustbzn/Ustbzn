#!/usr/bin/env python3
# -- coding:UTF-8 --

import math
import rospy
from can_msgs.msg import Frame
from daisch_ifs2000_driver.msg import GPFPD


def callback(data):
    # speed
    if data.id == 514:
        speed = (data.data[2] * 256 + data.data[1]) * 2 * math.pi * 0.519 / 10 / 23.25
        #rospy.loginfo('speed: %f m/s' % speed)

    # hydraulic pressure
    elif data.id == 518:
        intakePress = (data.data[0] + (data.data[1] % 16) * 256) / 100
        leftPress = (data.data[1] // 16 + data.data[2] * 16) / 100
        rightPress = (data.data[3] + (data.data[4] % 16) * 256) / 100
       #rospy.loginfo('Pressure >--> Intake: %f Mpa, left: %f Mpa, right: %f Mpa'
       #               % (intakePress, leftPress, rightPress))

    # articulated angle
    elif data.id == 773:
        # a = bytearray(data.data)
        # can_data = [x for x in a]
        # gamma = ((can_data[0] * 256 + can_data[1]) / 100 - 570) * math.pi / 180
        # gamma = ((data.data[0] * 256 + data.data[1]) / 100 - 570)
        gamma = (data.data[0] * 256 + data.data[1]) / 100
        rospy.loginfo('Articulated angle: %f' % gamma)

    # tire pressure and temperature



def gps_callback(gps):
    if gps.heading < 270:
        heading = (90 - gps.heading) * math.pi / 180
    else:
        heading = (450 - gps.heading) * math.pi / 180
    v_sqrt = math.sqrt(gps.vel_e ** 2 + gps.vel_n ** 2)
    v_heading = gps.vel_e * math.cos(heading) + gps.vel_n * math.sin(heading)
    #rospy.loginfo('v_sqrt: %f m/s\n v_heading: %f m/s' % (v_sqrt, v_heading))


def msg_pub():
    rospy.init_node('msg_pub')
    rospy.Subscriber('received_messages', Frame, callback)
    rospy.Subscriber('gpfpd', GPFPD, gps_callback)
    rate = rospy.Rate(1)
    while not rospy.is_shutdown():
        rate.sleep()
    rospy.spin()


if __name__ == '__main__':
    try:
        msg_pub()
    except rospy.ROSInterruptException:
        pass
