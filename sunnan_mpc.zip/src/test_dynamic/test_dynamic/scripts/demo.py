a = bin(256)
print(255%2)
print(bin(256))
print(int(1.9))