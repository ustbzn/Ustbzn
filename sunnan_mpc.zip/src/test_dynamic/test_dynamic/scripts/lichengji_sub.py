#!/usr/bin/env python3
# -- coding:UTF-8 --

import math
import time
import rospy
from can_msgs.msg import Frame
from test_dynamic.msg import info_kache

v_odo = 0
pres_intake = 0
pres_right = 0
pres_left = 0
gamma = 0


def callback(data):
    global v_odo
    global pres_intake
    global pres_right
    global pres_left
    global gamma

    if data.id == 514:  # Speed
        v_odo = (data.data[2] * 256 + data.data[1]) * 2 * math.pi * 0.519 / 10 / 23.25
        rospy.loginfo('Speed from speedometer: %d', v_odo)
    elif data.id == 518:  # Pressure
        pres_intake = data[0] + (data[1] % 2) * 256
        pres_right = data[1] // 2 + (data[2] % 4) * 256
        pres_left = data[2] // 4 + data[3] * 256
        rospy.loginfo('PressureIntake: %d, Right: %d, Left: %d', pres_intake, pres_right, pres_left)
    elif data.id == 773:
        gamma = ((data.data[0] * 256 + data.data[1]) / 100 - 570) * math.pi / 180
        rospy.loginfo('Articulated angle: %d', gamma)


def info_pub():
    global v_odo
    global pres_intake
    global pres_right
    global pres_left
    global gamma

    rospy.init_node('info_pub')
    rospy.Subscriber('received_messages', Frame, callback)
    rospy.Subscriber('received_messages', Frame, callback)
    vehicleInfo_pub = rospy.Publisher('information', info_kache, queue_size=1000)
    T = 0.001
    rate = rospy.Rate(1 / T)
    while not rospy.is_shutdown():
        rate.sleep()
    rospy.spin()


if __name__ == '__main__':
    try:
        info_pub()
    except rospy.ROSInterruptException:
        pass
