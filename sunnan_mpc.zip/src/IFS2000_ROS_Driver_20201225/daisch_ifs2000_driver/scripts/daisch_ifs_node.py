#!/usr/bin/env python
import rospy
import sys
from daisch_ifs2000_driver.msg import *
import parser

import serial, string, math, time, calendar

def check_ifs_checksum(ifs_sentence):
    split_sentence = ifs_sentence.split('*')
    if len(split_sentence) != 2:
        # No checksum bytes were found: improperly formatted/incomplete.
        return False
    transmitted_checksum = split_sentence[1].strip()

    # Remove the $ at the front
    data_to_checksum = split_sentence[0][1:]
    checksum = 0
    for c in data_to_checksum:
        checksum ^= ord(c)

    return checksum == int(transmitted_checksum, 16)

#nmea_utc should be a string of form hhmmss
def convertNMEATimeToROS(ifs_utc):
    #Get current time in UTC for date information
    utc_struct = time.gmtime() #immutable, so cannot modify this one
    utc_list = list(utc_struct)
    hours = int(nmea_utc[0:2])
    minutes = int(nmea_utc[2:4])
    seconds = int(nmea_utc[4:6])
    utc_list[3] = hours
    utc_list[4] = minutes
    utc_list[5] = seconds
    unix_time = calendar.timegm(tuple(utc_list))
    return rospy.Time.from_sec(unix_time)
    
def publishIFSData(data_map, ifs_data, ifs_pub):
    for entry in data_map:
        if hasattr(ifs_data, entry):
            setattr(ifs_data, entry, data_map[entry])
    ifs_pub.publish(ifs_data)
    print(ifs_data._type)
    return

if __name__ == "__main__":
    # init IFS port parameter
    try:
        IFSPort = sys.argv[1]
    except IndexError:
        IFSPort = '/dev/ttyS0'
        print('Default port used: /dev/ttyS0')
    
    try:
        IFSrate = sys.argv[2]
    except IndexError:
        IFSPort = 115200
        print('Default baudrate used: 115200')
    
    #init publisher
    rospy.init_node('daisch_ifs2000_node')
    ifs_queue_size = 10
    GPFPDPub = rospy.Publisher('gpfpd', GPFPD, queue_size=ifs_queue_size)
    GPGGAPub = rospy.Publisher('gpgga', GPGGA, queue_size=ifs_queue_size)
    IFDYNPub = rospy.Publisher('ifdyn', IFDYN, queue_size=ifs_queue_size)
    IFGGAPub = rospy.Publisher('ifgga', IFGGA, queue_size=ifs_queue_size)
    IFLCPPub = rospy.Publisher('iflcp', IFLCP, queue_size=ifs_queue_size)
    IFRAWPub = rospy.Publisher('ifraw', IFRAW, queue_size=ifs_queue_size)
    GPFPDData = GPFPD()
    GPGGAData = GPGGA()
    IFDYNData = IFDYN()
    IFGGAData = IFGGA()
    IFLCPData = IFLCP()
    IFRAWData = IFRAW()

    try:
        IFS = serial.Serial(port=IFSPort, baudrate=IFSrate, timeout=2)
        #Read in GPS
        while not rospy.is_shutdown():
            #read GPS line
            data = IFS.readline().strip()

            if not check_ifs_checksum(data):
                if len(data) >0:
                    rospy.logwarn("Received a sentence with an invalid checksum. Sentence was: %s" % data)
                continue

            # timeNow = rospy.get_rostime()

            try:
                sentence = parser.parse_ifs_sentence(data)

                if not sentence:
                    continue

                if 'GGA' in sentence:
                    data_map = sentence["GGA"]
                    if data.startswith('$GP'):
                        publishIFSData(data_map, GPGGAData, GPGGAPub)
                    elif data.startswith('$IF'):
                        publishIFSData(data_map, IFGGAData, IFGGAPub)

                if 'FPD' in sentence:
                    data_map = sentence['FPD']
                    publishIFSData(data_map, GPFPDData, GPFPDPub)

                if 'DYN' in sentence:
                    data_map = sentence['DYN']
                    publishIFSData(data_map, IFDYNData, IFDYNPub)

                if 'LCP' in sentence:
                    data_map = sentence["LCP"]
                    publishIFSData(data_map, IFLCPData, IFLCPPub)
                    
                if 'RAW' in sentence:
                    data_map = sentence['RAW']
                    publishIFSData(data_map, IFRAWData, IFRAWPub)

            except ValueError as e:
                rospy.logwarn("Value error, likely due to missing fields in the messages. Error was: %s" % e)

    except rospy.ROSInterruptException:
        IFS.close() #Close GPS serial port