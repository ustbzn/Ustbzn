#!/usr/bin/env python
import rospy, inspect
from daisch_ifs2000_driver.msg import *

def callback(data):
    attributes = inspect.getmembers(data,lambda a:not(inspect.isroutine(a)))
    print(data._type)
    for a in attributes:
        if not(a[0].startswith('_') or a[0].endswith('_')):
            print(a[0], a[1])

def listener():

    # In ROS, nodes are uniquely named. If two nodes with the same
    # name are launched, the previous one is kicked off. The
    # anonymous=True flag means that rospy will choose a unique
    # name for our 'listener' node so that multiple listeners can
    # run simultaneously.
    rospy.init_node('listener', anonymous=True)

    rospy.Subscriber('gpfpd', GPFPD, callback)
    rospy.Subscriber('gpgga', GPGGA, callback)
    rospy.Subscriber('ifgga', IFGGA, callback)
    rospy.Subscriber('ifdyn', IFDYN, callback)
    rospy.Subscriber('iflcp', IFLCP, callback)
    rospy.Subscriber('ifraw', IFRAW, callback)

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    listener()