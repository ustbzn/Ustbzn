# Software License Agreement (BSD License)
#
# Copyright (c) 2013, Eric Perko
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
#  * Neither the names of the authors nor the names of their
#    affiliated organizations may be used to endorse or promote products derived
#    from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

import re
import time
import calendar
import math

def safe_float(field):
    try:
        return float(field)
    except ValueError:
        return float('NaN')


def safe_int(field):
    try:
        return int(field)
    except ValueError:
        return 0

def convert_latitude(field):
    return safe_float(field[0:2]) + safe_float(field[2:]) / 60.0

def convert_longitude(field):
    return safe_float(field[0:3]) + safe_float(field[3:]) / 60.0

def convert_time(nmea_utc):
    # Get current time in UTC for date information
    utc_struct = time.gmtime()  # immutable, so cannot modify this one
    utc_list = list(utc_struct)
    # If one of the time fields is empty, return NaN seconds
    if not nmea_utc[0:2] or not nmea_utc[2:4] or not nmea_utc[4:6]:
        return float('NaN')
    else:
        hours = int(nmea_utc[0:2])
        minutes = int(nmea_utc[2:4])
        seconds = int(nmea_utc[4:6])
        utc_list[3] = hours
        utc_list[4] = minutes
        utc_list[5] = seconds
        unix_time = calendar.timegm(tuple(utc_list))
        return unix_time

def convert_status_flag(status_flag):
    if status_flag == "A":
        return True
    elif status_flag == "V":
        return False
    else:
        return False

# Need this wrapper because math.radians doesn't auto convert inputs
def convert_deg_to_rads(degs):
    return math.radians(safe_float(degs))

"""Format for this dictionary is a sentence identifier (e.g. "GGA") as the key, with a
list of tuples where each tuple is a field name, conversion function and index
into the split sentence"""
parse_maps = {
    "GGA": [
        ("utc_time", str, 1),
        ("latitude", safe_float, 2),
        ("latitude_dir", str, 3),
        ("longitude", safe_float, 4),
        ("longitude_dir", str, 5),
        ("fix_type", int, 6),
        ("sat_num", safe_int, 7),
        ("hdop", safe_float, 8),
        ("altitude", safe_float, 9)
    ],
    "LCP": [
        ("pos_e", safe_float, 1),
        ("pos_n", safe_float, 2),
        ("pos_d", safe_float, 3),
    ],
    "DYN": [
        ("yaw", safe_float, 1),
        ("roll", safe_float, 2),
        ("pitch", safe_float, 3),
        ("vel_hori", safe_float, 4),
        ("vel_e", safe_float, 5),
        ("vel_n", safe_float, 6),
        ("vel_d", safe_float, 7),
        ("accel_x", safe_float, 8),
        ("accel_y", safe_float, 9),
        ("accel_z", safe_float, 10),
        ("ang_rate_x", safe_float, 11),
        ("ang_rate_y", safe_float, 12),
        ("ang_rate_z", safe_float, 13)
    ],
    "RAW": [
        ("accel_x", safe_float, 1),
        ("accel_y", safe_float, 2),
        ("accel_z", safe_float, 3),
        ("ang_rate_x", safe_float, 4),
        ("ang_rate_y", safe_float, 5),
        ("ang_rate_z", safe_float, 6),
        ("ang_x", safe_float, 7),
        ("ang_y", safe_float, 8),
        ("ang_z", safe_float, 9),
        ("gps_heading", safe_float, 10),
        ("course_ang", safe_float, 11),
        ("rl_ws", safe_float, 12),
        ("rr_ws", safe_float, 13)
    ],
    "FPD": [
        ("gps_week", safe_float, 1),
        ("gps_week_sec", safe_float, 2),
        ("heading", safe_float, 3),
        ("pitch", safe_float, 4),
        ("roll", safe_float, 5),
        ("latitude", safe_float, 6),
        ("longitude", safe_float, 7),
        ("altitude", safe_float, 8),
        ("vel_e", safe_float, 9),
        ("vel_n", safe_float, 10),
        ("vel_u", safe_float, 11),
        ("sat_num1", safe_int, 13),
        ("sat_num2", safe_int, 14),
        ("status", str, 15)
    ],
}

def parse_ifs_sentence(ifs_sentence):
    # Check for a valid nmea sentence

    if not re.match(
            r'(^\$GP|^\$IF).*\*[0-9A-Fa-f]{2}$', ifs_sentence):
        return False
    fields = [field.strip(',') for field in ifs_sentence[:-3].split(',')]

    # Ignore the $ and talker ID portions (e.g. GP,IF)
    sentence_type = fields[0][3:]

    if sentence_type not in parse_maps:
        return False

    parse_map = parse_maps[sentence_type]

    parsed_sentence = {}
    for entry in parse_map:
        parsed_sentence[entry[0]] = entry[1](fields[entry[2]])

    return {sentence_type: parsed_sentence}