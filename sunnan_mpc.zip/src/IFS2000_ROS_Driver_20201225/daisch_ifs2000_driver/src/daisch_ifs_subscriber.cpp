#include "ros/ros.h"
#include "std_msgs/String.h"

#include <daisch_ifs2000_driver/GPFPD.h>
#include <daisch_ifs2000_driver/GPGGA.h>
#include <daisch_ifs2000_driver/IFGGA.h>
#include <daisch_ifs2000_driver/IFDYN.h>
#include <daisch_ifs2000_driver/IFLCP.h>
#include <daisch_ifs2000_driver/IFRAW.h>

void gpfpdCallback(const daisch_ifs2000_driver::GPFPD::ConstPtr& data)
{
	ROS_INFO("GPS Week:     [%.4f]", data->gps_week);
	ROS_INFO("GPS Week Sec: [%.4f]", data->gps_week_sec);
	ROS_INFO("Heading:      [%.4f]", data->heading);
	ROS_INFO("Pitch:        [%.4f]", data->pitch);
	ROS_INFO("Roll:         [%.4f]", data->roll);
	ROS_INFO("Latitude:     [%.4f]", data->latitude);
	ROS_INFO("Longitude:    [%.4f]", data->longitude);
	ROS_INFO("Altitude:     [%.4f]", data->altitude);
}

int main(int argc, char **argv)
{
	ros::init(argc, argv, "listener");

	ros::NodeHandle n;

	ros::Subscriber sub = n.subscribe("gpfpd", 10, gpfpdCallback);

	ros::spin();

	return 0;
}