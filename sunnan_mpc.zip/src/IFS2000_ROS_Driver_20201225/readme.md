# 戴世智能IFS 2000组合惯导ROS驱动配置

## 运行环境
1. Ubuntu 16.04 LTS
2. ROS Kinetic Kame

## 配置步骤
1.  安装[catkin配置工具](http://wiki.ros.org/catkin)
    * 运行以下指令：
      `$ sudo apt-get install ros-<ros_version>-catkin`
    * 其中`<ros_version>`对于当前ROS版本（kinetic, groovy, 等），可通过以下命令查询：
      `$ rosversion -d`
    * 多数情况下catkin已随ROS一同安装
2.  将daisch_ifs2000_driver文件夹拷贝至catkin工作目录下的/src目录下
  * 如尚未创建：

    `$ mkdir -p ~/catkin_ws/src`
3.  运行catkin_make安装驱动
    1.  更改当前路径至~/catkin_ws/
        `$ cd ~/catkin_ws/`
    2.  运行catkin_make命令
        `$ catkin_make `

4.  更新.bashrc文件
    1.  使用gedit（或vim）编辑
        `$ gedit ~/.bashrc` 
    2.  添加以下内容至`.bashrc` ：
        `source ~/catkin_ws/devel/setup.bash`
    3.  更新后需要重新打开terminal或重新启动系统

## 调用测试

1.  运行ROS Master

    `$ roscore`

2.  确定IFS2000对应串口
    通过以下命令搜索含有'tty'的串口设备

    `$ dmesg | grep tty` 

3.  设置串口许可权限
    假设IFS2000对应串口为`/dev/ttyS0`，运行以下指令设置串口权限：

    `$ sudo chmod 666 /dev/ttyS0`

4.  串口数据发布（Publisher）
  * syntax:
    `$ rosrun daisch_ifs2000_driver daisch_ifs_node.py <arg:device> <arg:baud_rate>`

  * 示例：
    `$ rosrun daisch_ifs2000_driver daisch_ifs_node.py /dev/ttyS0 115200`

  * 节点解析报文数据后将数据整合为一结构体（详见“话题消息”部分）发布至以下话题：
    `'gpfpd', 'gpgga', 'ifgga', 'ifdyn', 'iflcp', 'ifraw'`
5.  话题订阅（Subscriber）示例（Python）
  * 在新的Linux终端运行订阅节点：
    `$ rosrun daisch_ifs2000_driver daisch_ifs_subscriber.py`
  * 该节点订阅了所有话题，并输出当前接收的话题类型及数据
  * 如需在其他Python项目中使用daisch_ifs2000_driver的消息类型，需在daisch_ifs2000_driver已成功配置之后导入相应模块：
    ```python
    from daisch_ifs2000_driver.msg import *
    ```


## 与C++集成
daisch_ifs2000_driver/src文件夹下包括一个简单的c++的订阅节点（Subscriber node）示例：daisch_ifs_subscriber.cpp。该节点订阅了`'gpfpd'`话题，并输出由此接收的数据。如需编译该文件，可更新daisch_ifs2000_driver/CMakeLists.txt文件，增加（取消注释）如下指令：

```cmake
add_executable(daisch_ifs_subscriber src/daisch_ifs_subscriber.cpp)
target_link_libraries(daisch_ifs_subscriber ${catkin_LIBRARIES})
add_dependencies(daisch_ifs_subscriber daisch_ifs_driver_generate_messages_cpp)
```
随后更改当前路径至~/catkin_ws/，再次运行catkin_make命令。以上代码将daisch_ifs_subscriber.cpp编译为daisch_ifs2000_driver模块下名为daisch_ifs_subscriber的可执行文件，可通过以下命令执行：

`$ rosrun daisch_ifs2000_driver daisch_ifs_subscriber`

如需在其他C++项目中使用IFS2000发布的消息，在成功配置daisch_ifs2000_driver后添加：

	#include <daisch_ifs2000_driver/GPFPD.h>
	#include <daisch_ifs2000_driver/GPGGA.h>
	#include <daisch_ifs2000_driver/IFGGA.h>
	#include <daisch_ifs2000_driver/IFDYN.h>
	#include <daisch_ifs2000_driver/IFLCP.h>
	#include <daisch_ifs2000_driver/IFRAW.h>

## 话题消息定义.
#### GPFPD
      float64 gps_week
      float64 gps_week_sec
      float64 heading
      float64 pitch
      float64 roll
      float64 latitude
      float64 longitude
      float64 altitude
      float64 vel_e
      float64 vel_n
      float64 vel_u
      float64 sat_num1
      float64 sat_num2
      string 	status
#### GPGGA
      string 	utc_time
      float64 latitude
      string 	latitude_dir
      float64 longitude
      string 	longitude_dir
      float64 altitude
      uint8 	fix_type
      int32 	sat_num
      float64 hdop
#### IFGGA
同GPGGA
#### IFDYN
      float64 yaw
      float64 roll
      float64 pitch
      float64 vel_hori
      float64 vel_e
      float64 vel_n
      float64 vel_d
      float64 accel_x
      float64 accel_y
      float64 accel_z
      float64 ang_rate_x
      float64 ang_rate_y
      float64 ang_rate_z
#### IFLCP
      float64 pos_e
      float64 pos_n
      float64 pos_d
#### IFRAW
      float64 accel_x
      float64 accel_y
      float64 accel_z
      float64 ang_rate_x
      float64 ang_rate_y
      float64 ang_rate_z
      float64 ang_x
      float64 ang_y
      float64 ang_z
      float64 gps_heading
      float64 course_ang
      float64 rl_ws
      float64 rr_ws

## 数据丢失问题
ROS开发者在[Bitbucket.org](https://bitbucket.org/cfok/controlit/issues/23/try-increasing-buffer-size-of-ros-topic)上讨论过订阅节点（Subscriber node）无法收到发布节点（Publisher node）消息的问题。建议的解决方案是修改订阅节点和发布节点的消息队列长度（queue_size）。
Python: `~\scripts\daisch_ifs_node.py`

```python
#init publisher
rospy.init_node('daisch_ifs_node')
ifs_queue_size = 10
GPFPDPub = rospy.Publisher('gpfpd', GPFPD, queue_size=ifs_queue_size)
...
```
C++: `~\src\daisch_ifs_subscriber.cpp`
```c++
ros::init(argc, argv, "listener");
ros::NodeHandle n;
ros::Subscriber sub = n.subscribe("gpfpd", 10, gpfpdCallback);
```

ROS的[Wiki](http://wiki.ros.org/rospy/Overview/Publishers%20and%20Subscribers)对队列长度的选择作了更详细的解释。

## 变更记录

2020年12月25日：更新了校验和计算函数