#!/usr/bin/env python3
# -- coding:UTF-8 --

import casadi as ca
import numpy as np


def nmpc_solver(T, Np, Nc, init_control, c_p):
    """
    铰接车非线性模型预测控制器（Nonlinear Model Predictive Controller - NMPC）
    Version of CasADi_Multiple_shooting
    求解控制增量以便对控制增量也进行约束
    """

    # ！参数定义
    lf = 1.620  # 铰接车前车体车桥中心点到铰接点的距离
    lr = 1.923  # 铰接车后车体车桥中心点到铰接点的距离

    # ！描述车辆状态方程
    # ！！定义状态变量
    # 将上一时刻的控制量作为状态量，在之后的预测过程中+控制增量即为之后的控制量
    vf = ca.SX.sym('vf')
    gamma_dot = ca.SX.sym('gamma_dot')
    # 其他状态量不变
    xf = ca.SX.sym('xf')  # x轴位置
    yf = ca.SX.sym('yf')  # y轴位置
    thetaf = ca.SX.sym('thetaf')  # 航向角
    gamma = ca.SX.sym('gamma')  # 铰接角
    states = ca.vertcat(vf, gamma_dot, xf, yf, thetaf, gamma)  # 构建LHD的状态量矩阵，此处需要以(Nx * 1)的格式呈现
    n_states = states.size()[0]  # 获取状态量的尺寸

    # ！！定义控制变量（增量）
    delta_vf = ca.SX.sym('delta_vf')  # 纵向速度
    delta_gamma_dot = ca.SX.sym('delta_gamma_dot')  # 铰接角速度
    controls = ca.vertcat(delta_vf, delta_gamma_dot)  # 构建LHD的控制量矩阵，此处需要以（Nc * 1）的格式呈现
    n_controls = controls.size()[0]  # 获取控制量的尺寸

    # ！！构建运动学模型
    rhs = ca.vertcat(delta_vf / T,
                     delta_gamma_dot / T,
                     (vf + delta_vf) * ca.cos(thetaf),
                     (vf + delta_vf) * ca.sin(thetaf),
                     ((vf + delta_vf) * ca.sin(gamma) / (lr + lf * ca.cos(gamma))) + (
                             (gamma_dot + delta_gamma_dot) * lr / (lr + lf * ca.cos(gamma))),
                     (gamma_dot + delta_gamma_dot)) # 在该矩阵里将控制增量积分就可以得到控制量

    # ！！利用CasADi构建一个函数来代表运动学模型，测出类似与python的
    # def f(states, controls):
    #     return rhs
    f = ca.Function('f', [states, controls], [rhs], ['input_state', 'control_input'], ['rhs'])

    # ！构建NMPC
    # ！！定义相关矩阵
    U = ca.SX.sym('U', n_controls, Nc)  # Nc步的控制输出
    X = ca.SX.sym('X', n_states, Np + 1)  # Np步的预测输出
    # print(X)
    X_now = ca.SX.sym('X_now', n_states, 1)  # 铰接车此时刻位置
    X_ref = ca.SX.sym('X_ref', n_states - n_controls, Np)  # 铰接车下一时刻位置

    # ！！定义Q,R矩阵
    Q = np.array([[0.1, 0.0, 0.0, 0.0],
                  [0.0, 0.1, 0.0, 0.0],
                  [0.0, 0.0, 0.1, 0.0],
                  [0.0, 0.0, 0.0, 0.0]])  # (Nx * Nx)
    R = np.array([[0.001, 0.0],
                  [0.0, 0.001]])  # (Nc * Nc)

    # ！！定义目标函数
    obj = 0  # 初始化目标函数
    g = [X[:, 0] - X_now[:, 0]]  # 创建存储X差值的矩阵

    # print(X)

    # ！！计算Np时域内的铰接车预测位置
    for i in range(Np):
        if i <= Nc - 1:
            obj = obj + ca.mtimes([(X[2:, i] - X_ref[:, i]).T, Q, (X[2:, i] - X_ref[:, i])]) \
                  + ca.mtimes([U[:, i].T, R, U[:, i]])
            x_next_ = f(X[:, i], U[:, i]) * T + X[:, i]
            g.append(X[:, i + 1] - x_next_[:])  # 对状态量进行差值（此处为何Single_shooting的唯一区别）
        else:  # 超出控制时域Nc后，控制量都以第Nc步的值计算
            obj = obj + ca.mtimes([(X[2:, i] - X_ref[:, i]).T, Q, (X[2:, i] - X_ref[:, i])]) \
                  + ca.mtimes([U[:, Nc - 1].T, R, U[:, Nc - 1]])
            x_next_ = f(X[:, i], U[:, Nc - 1]) * T + X[:, i]
            g.append(X[:, i + 1] - x_next_[:])  # 对状态量进行差值

    # ！！定义求解器的变量（包含状态量的差值）
    opt_variables = ca.vertcat(ca.reshape(U, -1, 1), ca.reshape(X, -1, 1))
    opt_params = ca.vertcat(ca.reshape(X_now, -1, 1), ca.reshape(X_ref, -1, 1))

    # ！定义NLP问题，‘f’为目标函数，'x'为需要寻找的优化结果（此处未控制量），'p'为系统参数（此刻装状态量+参考路径），'g'为状态量约束
    nlp_prob = {'f': obj, 'x': opt_variables, 'p': opt_params, 'g': ca.vertcat(*g)}

    # ！！求解器参数设置
    opts_setting = {'ipopt.max_iter': 100, 'ipopt.print_level': 0, 'print_time': 0,
                    'ipopt.acceptable_tol': 1e-8, 'ipopt.acceptable_obj_change_tol': 1e-6}

    # ！！定义求解器
    solver = ca.nlpsol('solver', 'ipopt', nlp_prob, opts_setting)

    # ！！定义约束
    lbg = 0.0
    ubg = 0.0
    lbx = []
    ubx = []

    lim = 0.33
    
    if (-0.14 < c_p[1] < 0.14) & (-0.75 < c_p[5] < 0.75):
        lower_delta_gamma_dot = (-0.14) - c_p[1]
        upper_delta_gamma_dot = 0.14 - c_p[1]
    elif (c_p[1] >= 0.14) or (c_p[5] >= 0.75):
        lower_delta_gamma_dot = -0.28
        upper_delta_gamma_dot = 0
    elif (c_p[1] <= -0.14) or (c_p[5] <= -0.75):
        lower_delta_gamma_dot = 0
        upper_delta_gamma_dot = 0.28

    if c_p[0] <= 0.9:
        lower_delta_v = 0 
        upper_delta_v = 0.1
    elif 0.9 < c_p[0] < 1.1:
        lower_delta_v = -0.01 
        upper_delta_v = 0.01
    else:
        lower_delta_v = -0.05 
        upper_delta_v = 0


    for _ in range(Nc):
        lbx.append(lower_delta_v)
        lbx.append(lower_delta_gamma_dot)
        ubx.append(upper_delta_v)
        ubx.append(upper_delta_gamma_dot)

    for _ in range(Np + 1):  # note that this is different with the method using structure
        lbx.append(-np.inf)
        lbx.append(-np.inf)
        lbx.append(-np.inf)
        lbx.append(-np.inf)
        lbx.append(-np.inf)
        lbx.append(-np.inf)
        ubx.append(np.inf)
        ubx.append(np.inf)
        ubx.append(np.inf)
        ubx.append(np.inf)
        ubx.append(np.inf)
        ubx.append(np.inf)

    res = solver(x0=init_control, p=c_p, lbg=lbg, lbx=lbx, ubg=ubg, ubx=ubx)

    return res
