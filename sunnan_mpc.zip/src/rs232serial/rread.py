#!/usr/bin/env python
# license removed for brevity
__metaclass__ = type
import rospy
from std_msgs.msg import String
import serial
from rs232serial.msg import dgps
import re
import math

def lookup(dataframe,bit):
    index_head = 0
    index_tail = 0
    for i in range(bit):
        index_head = dataframe.find(',')
        index_tail = dataframe.find(',',index_head+1)
        if index_tail!=-1:
            data = float(dataframe[index_head+1:index_tail])
            dataframe = dataframe[index_tail:]
            index_head = index_tail+1
        else:
            data = int(dataframe[index_head+1:index_head+2])
    return data

def sum(list):
    s = 0
    for x in list:
        s += x
    return s

def average(list):
    avg = 0
    avg = sum(list)/(len(list)*1.0)
    return avg

def transform(information):
    list1 = []
    lst1 = []
    while len(list1) <= 5:
        list1.append(information)
    i = 0
    while i <= len(list1):
            lst1.append(float(list1.pop()))
            i += 1
    newinformation = average(lst1)
    # list1.clear()
    # lst1.clear() 
    return newinformation

def receive():
    # Initialization
    pub = rospy.Publisher('GpsIns', dgps ,queue_size=10)
    rospy.init_node('serial_gps', anonymous=True)
    rate = rospy.Rate(20) # 10hz
    Buffer = ''
    Buffer_remains = ''
    temp = ''
    ser = serial.Serial('/dev/ttyTHS0',115200,timeout=0)
    notFull = True
    info = dgps()
    info1 = dgps()
    # In the following part, first fill up the buffer,then find each dataframe,
    # takeout the full dataframe,then the remains are located in the head,then
    # read serial and get data.So repeatedly,the buffer is filled then released
    # and the filled.
    while not rospy.is_shutdown():
        index = 0
        tail = 0
        Is_all = False
        while notFull:
            if len(Buffer)<180:
                data = ser.read(180)
                Buffer = Buffer_remains + data
                Buffer_remains = Buffer
            else:
                notFull = False
        index = Buffer.find('$GPHPD')
        if index != -1:
            tail = Buffer.find('$GPHPD',index+1)
            if tail != -1:
                Is_all = True
        if Is_all:
            temp = Buffer[index:tail]
            Buffer = list(Buffer)
            Buffer_remains = Buffer[tail:]
            Buffer = ''.join(Buffer_remains)
            while len(Buffer)<180:
                data = ser.read(120)
                Buffer = Buffer + data
        """
        Please do not modify anything upon this line
        """
        info.header.stamp = rospy.Time.now()
        info.header.frame_id = '/my_gps'
        info.GPSWeek = lookup(temp,1)
        info.GPSTime = lookup(temp,2)
        info.Heading = lookup(temp,3)
        info.Pitch = lookup(temp,4)
        info.Roll = lookup(temp,5)
        info.Latitude = lookup(temp,6)
        info.Longitude = lookup(temp,7)
        info.Altitude = lookup(temp,8)
        info.De = lookup(temp,9)
        info.Dn = lookup(temp,10)
        info.Du = lookup(temp,11)
        info.Ve = lookup(temp,12)
        info.Vn = lookup(temp,13)   
        info.Vu = lookup(temp,14)
        info.Ae = lookup(temp,15)
        info.An = lookup(temp,16)
        info.Au = lookup(temp,17)
        info.Baseline = lookup(temp,18)
        info.NSV1 = lookup(temp,19)
        info.NSV2 = lookup(temp,20)
        info.GPSStatus = lookup(temp,21)

        info1.header.stamp = info.header.stamp
        info1.header.frame_id = '/my_gps'
        info1.GPSWeek = transform(info.GPSWeek)
        info1.GPSTime = transform(info.GPSTime)
        info1.Heading = transform(info.Heading)
        info1.Pitch = transform(info.Pitch)
        info1.Roll = transform(info.Roll)
        info1.Latitude = transform(info.Latitude)
        info1.Longitude = transform(info.Longitude)
        info1.Altitude = transform(info.Altitude)
        info1.De = transform(info.De)
        info1.Dn = transform(info.Dn)
        info1.Du = transform(info.Du)
        info1.Ve = transform(info.Ve)
        info1.Vn = transform(info.Vn)   
        info1.Vu = transform(info.Vu)
        info1.Ae = transform(info.Ae)
        info1.An = transform(info.An)
        info1.Au = transform(info.Au)
        info1.Baseline = transform(info.Baseline)
        info1.NSV1 = transform(info.NSV1)
        info1.NSV2 = transform(info.NSV2)
        info1.GPSStatus = transform(info.GPSStatus)
          
        # disp ='Ve is:%s, Vn is : %s, GPSStatus is %s' %(info.Ve,info.Vn,info.GPSStatus)
        # disp = '%s' %info
        # disp ='GPSStatus is :%s' %(info.GPSStatus)
        rospy.loginfo(info1)
        # print temp
        pub.publish(info1)
        rate.sleep()


    
if __name__ == '__main__':
    try:
        receive()
    except rospy.ROSInterruptException:
        pass
