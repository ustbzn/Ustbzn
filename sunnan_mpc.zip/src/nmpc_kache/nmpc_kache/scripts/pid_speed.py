#!/usr/bin/env python3
# -- coding:UTF-8 --


import math
import time

import numpy as np

import PID
import rospy
from can_msgs.msg import Frame
from rs232serial.msg import dgps
from std_msgs.msg import Float32MultiArray

v = 0
ctrl = [0, 0]


def data_transfer(value, id_tocan):
    cmd = Frame()
    cmd.header.stamp = rospy.Time.now()
    cmd.header.frame_id = ''
    cmd.id = id_tocan
    cmd.is_rtr = False
    cmd.is_extended = False
    cmd.is_error = False
    cmd.dlc = 0x8

    value = math.ceil(value)
    if value > 255:
        value = 255
    elif value < 0:
        value = 0
    print('throttle:', value)
    data_array = bytearray([value, 0, 0, 0, 0, 0, 0, 0])
    cmd.data = data_array
    return cmd


def speed_callback(data):
    global v
    if data.id == 218050563:
        a = bytearray(data.data)
        can_data = [x for x in a]
        if can_data[5] < 100:
            v = 0.1 * can_data[5]
        elif 100 < can_data[5] < 200:
            v = 100 * 0.1 + (can_data[5] - 100) * 0.2
        else:
            v = 100 * 0.1 + 100 * 0.2 + (can_data[5] - 200) * 1
        v = v / 3.6  # kph to mps


def control_callback(data):
    global ctrl
    ctrl = data.data


def chassis_control():
    global v
    global ctrl

    # Define parameters of PID
    P_v = 100.0
    I_v = 10.0
    D_v = 0.0
    
    # Initialize ROS node
    rospy.init_node('control_output', anonymous=True)
    T = 0.25
    T_pid = 0.025
    rate = rospy.Rate(1 / T)

    rospy.Subscriber('received_messages', Frame, speed_callback)
    rospy.Subscriber('nmpc_output', Float32MultiArray, control_callback)

    cmd_pub = rospy.Publisher('sent_messages', Frame, queue_size=1)

    id_tocan = 0x261
    pid_v = PID.PID(P_v, I_v, D_v)
    pid_v.clear()
    pid_v.setSampleTime(T_pid)
    
    while not rospy.is_shutdown():
        # 加速
        v_target = ctrl[0]
        pid_v.SetPoint = v_target
        t1 = time.time()
        t2 = time.time()
        while not (t2 - t1 > T):
            v_feedback_value = v
            pid_v.update(v_feedback_value)
            throttle_value = pid_v.output

            # 测试使用
            print('v:', v_target, v, throttle_value)

            # Send to PLC
            cmd_tocan = throttle_value

            cmd = data_transfer(cmd_tocan, id_tocan)
            cmd_pub.publish(cmd)
            time.sleep(T_pid)
            t2 = time.time()
        rate.sleep()
    rospy.spin()


if __name__ == '__main__':
    try:
        chassis_control()
    except rospy.ROSInterruptException:
        pass
