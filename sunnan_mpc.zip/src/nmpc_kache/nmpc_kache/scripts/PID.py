#! usr/bin/env python3
# -- coding:utf-8 --

import time
import rospy
import math
from std_msgs.msg import String
from can_msgs.msg import Frame
import numpy as np


class PID:
    def __init__(self, P, I, D):
        self.Kp = P  # 比例系数
        self.Ki = I  # 积分系数
        self.Kd = D  # 微分系数
        self.sample_time = 0.00
        self.current_time = time.time()
        self.last_time = self.current_time  # 上一时刻时间
        self.clear()

    def clear(self):
        self.SetPoint = 0.0
        self.PTerm = 0.0
        self.ITerm = 0.0
        self.DTerm = 0.0
        self.last_error = 0.0
        self.int_error = 0.0
        self.output = 0.0

    def update(self, feedback_value):

        error = self.SetPoint - feedback_value  # 偏差，相当于e(t)
        # print(error)
        self.current_time = time.time()
        delta_time = self.current_time - self.last_time  # 相当于dt

        delta_error = error - self.last_error  # 相当于de(t)

        if delta_time >= self.sample_time:
            '''
            比例，反应系统的基本（当前）偏差e(t)，系数大，可以加快调节，减小误差，但过大的比例使系统稳定性下降，甚至造成系统不稳定；
            '''
            self.PTerm = self.Kp * error
            '''
            积分，反应系统的累计偏差，使系统消除稳态误差，提高无差度，因为有误差，积分调节就进行，直至无误差；
            '''
            self.ITerm += error * delta_time
            '''
            微分，反映系统偏差信号的变化率e(t)-e(t-1)，具有预见性，能预见偏差变化的趋势，
            产生超前的控制作用，在偏差还没有形成之前，已被微分调节作用消除，因此可以改善系统的动态性能。
            但是微分对噪声干扰有放大作用，加强微分对系统抗干扰不利。
            '''
            self.DTerm = 0.0  # 微分环节
            if delta_time > 0:
                self.DTerm = delta_error / delta_time

            self.last_time = self.current_time
            self.last_error = error
            # 输出
            # print(self.ITerm)
            self.output = self.PTerm + (self.Ki * self.ITerm) + (self.Kd * self.DTerm)

    def setSampleTime(self, sample_time):
        self.sample_time = sample_time


'''
def can_callback(data):
    gamma = ( data.data[4] - 40 ) * math.pi / 180
    return gamma

def nmpc_callback(data):
    pass

def turn_tranform():

    # feedback
    gamma_data = np.zeros((1,2))
    time_data = []
    for i in range(2):
        gamma = rospy.Subscriber('received_messages', Frame, can_callback, queue_size=1000)
        time = time.time()
        for j in range(1):
            gamma_data[j + 1] = gamma_data[j]
        gamma_data[0] = gamma

        time_data.append(time)
    delta_time = time_data[1] - time_data[0]
    can_gamma_dot = ( gamma_data[1] - gamma_data[0] ) / delta_time

    #SetPoint
    nmpc_gamma_dot = rospy.Subscriber('sent_messages', Frame , nmpc_callback , queue_size=1000)


    pid = PID( 1 , 1 , 1 )
    pid.SetPoint = nmpc_gamma_dot
    feedback = can_gamma_dot
    for i in range(1, END):
        pid.update(feedback)
        output = pid.output
        if feedback - pid.SetPoint < 0.1:
            break
    gamma_dot = pid.update(feedback)
    return gamma_dot
'''
