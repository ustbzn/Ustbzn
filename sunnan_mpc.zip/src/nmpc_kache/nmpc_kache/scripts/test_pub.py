#!/usr/bin/env python3
# -- coding:UTF-8 --

import time
import rospy
from can_msgs.msg import Frame


def data_transfer(value, id_tocan):
    cmd = Frame()
    cmd.header.stamp = rospy.Time.now()
    cmd.header.frame_id = ''
    cmd.id = id_tocan
    cmd.is_rtr = False
    cmd.is_extended = False
    cmd.is_error = False
    cmd.dlc = 0x8

    # 油门指令
    if id_tocan == 0x261:
        data_array = bytearray([value, 0, 0, 0, 0, 0, 0, 0])
        cmd.data = data_array

    # 转向指令，左转为正，右转为负
    elif id_tocan == 0x161:
        if value >= 0:
            steer_left = value
            steer_right = 0
        else:
            steer_left = 0
            steer_right = -value
        data_array = bytearray([2, 0, 0, 0, 0, 0, steer_right, steer_left])
        cmd.data = data_array
    return cmd


def chassis_control():
    t1 = time.time()
    rospy.init_node('test_pub', anonymous=True)
    T = 0.05
    rate = rospy.Rate(1 / T)
    id_tocan = [0x261, 0x161]

    cmd_pub = rospy.Publisher('sent_messages', Frame, queue_size=1)
    throttle_value = 120

    while not rospy.is_shutdown():
        t2 = time.time()
        if t2 - t1 <= 8:
            steer_value = 0
        else:
            steer_value = -50
        cmd_tocan = [throttle_value, steer_value]
        for i in range(len(id_tocan)):
            cmd = data_transfer(cmd_tocan[i], id_tocan[i])
            print(cmd)
            cmd_pub.publish(cmd)
        rate.sleep()
    rospy.spin()


if __name__ == '__main__':
    try:
        chassis_control()
    except rospy.ROSInterruptException:
        pass
