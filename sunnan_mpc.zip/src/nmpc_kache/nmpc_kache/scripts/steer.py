#!/usr/bin/env python3
# -- coding:UTF-8 --


import math
import time
import PID
import rospy
from can_msgs.msg import Frame
from std_msgs.msg import Float32MultiArray

ctrl = [0, 0]


def data_transfer(value, id_tocan):
    cmd = Frame()
    cmd.header.stamp = rospy.Time.now()
    cmd.header.frame_id = ''
    cmd.id = id_tocan
    cmd.is_rtr = False
    cmd.is_extended = False
    cmd.is_error = False
    cmd.dlc = 0x8

    if value > 0:
        steer_left = math.ceil(value)
        if steer_left > 255:
            steer_left = 255
        steer_right = 0
    else:
        steer_left = 0
        steer_right = math.ceil(-value)
        if steer_right > 255:
            steer_right = 255
    print('steer_right:', steer_right, 'steer_left:', steer_left)
    data_array = bytearray([1, 0, 0, 0, 0, 0, steer_right, steer_left])
    cmd.data = data_array

    return cmd


def control_callback(data):
    global ctrl
    ctrl = data.data


def chassis_control():
    global ctrl

    # Initialize ROS node
    T = 0.1

    rospy.init_node('control_output', anonymous=True)
    rate = rospy.Rate(1 / T)
    rospy.Subscriber('nmpc_output', Float32MultiArray, control_callback)
    cmd_pub = rospy.Publisher('sent_messages', Frame, queue_size=1)

    id_tocan = 0x161

    while not rospy.is_shutdown():
        # 转向
        target = ctrl[1]
        if -0.005 < target < 0.005:
            steer_value = 0
        elif target >= 0.005:
            steer_value = 1000 * target + 25
        elif target <= -0.005:
            steer_value = 2400 * target - 15

        cmd_tocan = steer_value
        cmd = data_transfer(cmd_tocan, id_tocan)
        cmd_pub.publish(cmd)

        rate.sleep()
    rospy.spin()


if __name__ == '__main__':
    try:
        chassis_control()
    except rospy.ROSInterruptException:
        pass
