#!/usr/bin/env python3
# -- coding:UTF-8 --

"""
Author: Nan Sun
Main control node for path tracking
"""

import math
import time
import rospy
import numpy as np
# import vehicle_state as state
import path_reference as path
import solver_nmpc_mul_shooting as solver
from can_msgs.msg import Frame
from std_msgs.msg import Float32MultiArray
from nmpc_kache.msg import Record
from daisch_ifs2000_driver.msg import GPFPD

gamma = 0
v = 0
de = 0
dn = 0
heading = 0


def record_tf(de0, dn0, heading0, v_last, gamma_last, gamma_dot_last, de, dn, heading, v, gamma_now, gamma_dot, v_delta,
              gamma_dot_delta, xf, yf, thetaf, xr, yr, thetar, X_ref, delta_u1, delta_u2, u1, u2, solver_time,
              loop_time, t0, t1, time1, time2, time3, time4, time5, time6, time7):
    record = Record()
    record.de0 = de0
    record.dn0 = dn0
    record.heading0 = heading0
    record.v_last = v_last
    record.gamma_last = gamma_last
    record.gamma_dot_last = gamma_dot_last
    record.de = de
    record.dn = dn
    record.heading = heading
    record.v = v
    record.gamma_now = gamma_now
    record.gamma_dot = gamma_dot
    record.v_delta = v_delta
    record.gamma_dot_delta = gamma_dot_delta
    record.xf = xf
    record.yf = yf
    record.thetaf = thetaf
    record.xr = xr
    record.yr = yr
    record.thetar = thetar
    record.gamma_now = gamma_now
    record.x_ref = X_ref[0]
    record.y_ref = X_ref[1]
    record.theta_ref = X_ref[2]
    record.delta_u1 = delta_u1
    record.delta_u2 = delta_u2
    record.u1 = u1
    record.u2 = u2
    record.solver_time = solver_time
    record.loop_time = loop_time
    record.t0 = t0
    record.t1 = t1
    record.time1 = time1
    record.time2 = time2
    record.time3 = time3
    record.time4 = time4
    record.time5 = time5
    record.time6 = time6
    record.time7 = time7

    return record


def can_callback(data):
    global gamma
    global v

    # Get articulated angle
    if data.id == 773:
        a = bytearray(data.data)
        can_data = [x for x in a]
        gamma = ((can_data[0] * 256 + can_data[1]) / 100 - 92.5) * math.pi / 180

    # Get vehicle speed
    # if data.id == 514:
    #     a = bytearray(data.data)
    #     can_data = [x for x in a]
    #     v = (can_data[1] + can_data[2] * 256) * 2 * 0.519 * math.pi / 10 / 23.25


def gps_callback(gps):
    global de
    global dn
    global heading
    global v
    lat = float(gps.latitude)
    lon = float(gps.longitude)

    lat0 = 40.06
    lon0 = 116.81

    de = (lon - lon0) * 111000 * math.cos(lat * math.pi / 180)
    dn = (lat - lat0) * 111000

    if gps.heading < 270:
        heading = (90 - gps.heading) * math.pi / 180
    else:
        heading = (450 - gps.heading) * math.pi / 180

    # heading = heading + 0.005  # GPS角度矫正
    heading = heading + 0.0055  # GPS角度矫正

    v = math.sqrt(gps.vel_e ** 2 + gps.vel_n ** 2)
    # return de, dn, heading


def pos_tf(de0, dn0, heading0, de1, dn1, heading1):
    # l = 0.824 + 0.64  # GPS后天线到前轴中心纵向距离
    # w = 0.545  # GPS后天线到前轴中心横向距离
    l = 0  # GPS后天线到前轴中心纵向距离
    w = 0  # GPS后天线到前轴中心横向距离

    thetaf = heading1 - heading0

    de00 = de0 + w * math.sin(heading0) + l * math.cos(heading0)
    dn00 = dn0 - w * math.cos(heading0) + l * math.sin(heading0)

    dee = de1 + w * math.sin(heading1) + l * math.cos(heading1)
    dnn = dn1 - w * math.cos(heading1) + l * math.sin(heading1)

    xf = (dee - de00) * math.cos(heading0) + (dnn - dn00) * math.sin(heading0)
    yf = -(dee - de00) * math.sin(heading0) + (dnn - dn00) * math.cos(heading0)
    return xf, yf, thetaf


def control_output():
    global gamma
    global v
    global de
    global dn
    global heading

    # Starting time
    t0 = time.time()

    # Define parameters
    T = 0.2  # 时间间隔
    n_states = 4  # 状态量个数
    n_controls = 2  # 控制量个数
    Np = 30  # 预测步长
    Nc = 1  # 控制步长
    v_ref = 2.1  # 参考速度

    lf = 1.620  # Length from center of front axle to articulated point
    lr = 1.923  # Length from center of rear axle to articulated point

    # 初始化ROS
    rospy.init_node('main_control')
    rate = rospy.Rate(1 / T)

    rospy.Subscriber('received_messages', Frame, can_callback)
    rospy.Subscriber('gpfpd', GPFPD, gps_callback)
    ctrl_pub = rospy.Publisher('nmpc_output', Float32MultiArray, queue_size=2)
    record_pub = rospy.Publisher('nmpc_record', Record, queue_size=1)

    # Get first pose
    gps1st = rospy.wait_for_message('gpfpd', GPFPD)
    lat = float(gps1st.latitude)
    lon = float(gps1st.longitude)

    lat0 = 40.06
    lon0 = 116.81

    de1st = (lon - lon0) * 111000 * math.cos(lat * math.pi / 180)
    dn1st = (lat - lat0) * 111000

    if gps1st.heading < 270:
        heading1st = (90 - gps1st.heading) * math.pi / 180
    else:
        heading1st = (450 - gps1st.heading) * math.pi / 180

    # heading1st = heading1st + 0.005  # GPS角度矫正
    heading1st = heading1st + 0.0055  # GPS角度矫正
    de0, dn0, heading0 = de1st, dn1st, heading1st

    # Get first state
    v_last = v
    gamma_last = gamma
    t1 = time.time()
    time_last = t1

    # Start the loop
    count_while = 1

    while not rospy.is_shutdown():
        time1 = time.time()

        # 更新状态量+控制量
        de, dn, heading = de, dn, heading
        time5 = time.time()
        # print('time5:', time5 - time1)
        # Pose transform
        xf, yf, thetaf = pos_tf(de0, dn0, heading0, de, dn, heading)
        time_now = time.time()
        v_now = v
        gamma_now = gamma
        gamma_dot = (gamma_now - gamma_last) / (time_now - time_last)

        # print("v=", v_now, "gamma_dot=", gamma_dot)

        # Calculate pose of rear body
        xr = xf - lf * math.cos(thetaf) - lr * math.cos(thetaf - gamma)
        yr = yf - lf * math.sin(thetaf) - lr * math.sin(thetaf - gamma)
        thetar = thetaf - gamma
        if thetar <= -math.pi:
            thetar = thetar + 2 * math.pi
        elif thetar >= math.pi:
            thetar = thetar - 2 * math.pi

        # Integration of the matrix
        current_state = np.matrix([[xf], [yf], [thetaf], [gamma_now]])
        u0 = np.array([[v_now], [gamma_dot]])
        time6 = time.time()
        # print('time6:', time6 - time5)

        # 更新参考路径
        pos = [xf, yf, thetaf]
        
        next_states = path.get_path(pos, Np, T, v_ref, n_states)
        # print(next_states)
        time7 = time.time()
        # print('time7', time7 - time6)

        # 准备CasADi矩阵
        # 聚合c_p(控制量+状态量+参考路径)
        c_p = np.concatenate((current_state.reshape(-1, 1), next_states.reshape(-1, 1)))

        # 更新init_control(控制增量)
        init_control = np.concatenate((np.tile(u0.reshape(-1, 1), (Nc, 1)).reshape(-1, 1),
                                       np.tile(current_state, (Np + 1, 1)).reshape(-1, 1)))

        # 求解
        time2 = time.time()
        res = solver.nmpc_solver(T, Np, Nc, init_control, c_p)
        time3 = time.time()
        solver_time = time3 - time2
        # print("solver time:", solver_time)

        # 控制量输出
        estimated_opt = res['x'].full()
        u_all = estimated_opt[:int(n_controls * Nc)].reshape(Nc, n_controls)
        u = u_all[0, :].reshape(-1, 1)

        # 发送控制量至底层控制
        ctrl = [u[0, 0], u[1, 0]]
        ctrl_pub.publish(Float32MultiArray(data=ctrl))
        time4 = time.time()
        print("control variable:", ctrl)

        # msg记录
        loop_time = time4 - time1
        print("loop time:", time4 - time1)

        record = record_tf(de0, dn0, heading0, v_last, gamma_last, 0, de, dn, heading, v, gamma_now,
                           gamma_dot, 0, 0, xf, yf, thetaf, xr, yr, thetar, next_states[0, :], 0, 0,
                           u[0, 0], u[1, 0], solver_time, loop_time, t0, t1, time1, time2, time3, time4, time5, time6,
                           time7)
        record_pub.publish(record)

        # 此时刻变量赋值成上一时刻变量
        gamma_last = gamma_now
        time_last = time_now
        # print(count_while)
        count_while = count_while + 1

        rate.sleep()
    rospy.spin()


if __name__ == '__main__':
    try:
        control_output()
    except rospy.ROSInterruptException:
        pass
