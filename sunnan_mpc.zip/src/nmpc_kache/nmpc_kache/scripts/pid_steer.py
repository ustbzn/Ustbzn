#!/usr/bin/env python3
# -- coding:UTF-8 --


import math
import time
import PID
import rospy
from can_msgs.msg import Frame
from std_msgs.msg import Float32MultiArray


gamma = 0
ctrl = [0, 0]


def data_transfer(value, id_tocan):
    cmd = Frame()
    cmd.header.stamp = rospy.Time.now()
    cmd.header.frame_id = ''
    cmd.id = id_tocan
    cmd.is_rtr = False
    cmd.is_extended = False
    cmd.is_error = False
    cmd.dlc = 0x8

    if value > 0:
        steer_left = math.ceil(value)
        if steer_left > 255:
            steer_left = 255
        steer_right = 0
    else:
        steer_left = 0
        steer_right = math.ceil(-value)
        if steer_right > 255:
            steer_right = 255
    print('steer_right:', steer_right, 'steer_left:', steer_left)
    data_array = bytearray([2, 0, 0, 0, 0, 0, steer_right, steer_left])
    cmd.data = data_array

    return cmd


def can_callback(data):
    global gamma
    if data.id == 497:
        a = bytearray(data.data)
        can_data = [x for x in a]
        gamma = (42.65 - ((can_data[1] * 256 + can_data[0]) * 0.022 - 86) ) * math.pi / 180


def control_callback(data):
    global ctrl
    ctrl = data.data


def chassis_control():
    global gamma
    global ctrl

    # 定义转向PID参数
    P_s = 1000.0
    I_s = 0.0
    D_s = 0.0

    # Initialize ROS node
    T = 0.25
    T_pid = 0.1

    rospy.init_node('control_output', anonymous=True)
    rate = rospy.Rate(1 / T)

    rospy.Subscriber('received_messages', Frame, can_callback)
    rospy.Subscriber('nmpc_output', Float32MultiArray, control_callback)

    cmd_pub = rospy.Publisher('sent_messages', Frame, queue_size=1)

    id_tocan = 0x161
    pid_s = PID.PID(P_s, I_s, D_s)
    
    pid_s.setSampleTime(T_pid)

    while not rospy.is_shutdown():
        # 转向
        pid_s.clear()
        gamma_dot_target = ctrl[1]
        pid_s.SetPoint = gamma_dot_target
	
        gamma_last = gamma
        t0 = time.time()

        t1 = time.time()
        t2 = time.time()
        while not (t2 - t1 > T):
            gamma_now = gamma
            t3 = time.time()
            t_delta = t3 - t0
            gamma_dot = (gamma_now - gamma_last) / t_delta
            s_feedback_value = gamma_dot
            pid_s.update(s_feedback_value)
            steer_value = pid_s.output

            # 测试使用
            print('s:', gamma_dot_target, gamma_dot, steer_value)

            # Send to PLC
            cmd_tocan = steer_value

            cmd = data_transfer(cmd_tocan, id_tocan)
            cmd_pub.publish(cmd)

            time.sleep(T_pid)
            t2 = time.time()
            t0 = t3
            gamma_last = gamma_now
        rate.sleep()
    rospy.spin()


if __name__ == '__main__':
    try:
        chassis_control()
    except rospy.ROSInterruptException:
        pass
