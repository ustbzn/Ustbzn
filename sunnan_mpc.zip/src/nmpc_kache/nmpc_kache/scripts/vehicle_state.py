#!/usr/bin/env python3
# -- coding:UTF-8 --

import math
import rospy
import numpy as np
from can_msgs.msg import Frame
from daisch_ifs2000_driver.msg import GPFPDd


def get_gps():
    gps = rospy.wait_for_message('gpfpd', GPFPD)

    lat = float(gps.latitude)
    lon = float(gps.longitude)

    lat0 = 40.06
    lon0 = 116.81

    de = (lon - lon0) * 111000 * math.cos(lat * math.pi / 180)
    dn = (lat - lat0) * 111000

    if gps.heading < 270:
        heading = (90 - gps.heading) * math.pi / 180
    else:
        heading = (450 - gps.heading) * math.pi / 180

    heading = heading +0.005  # GPS角度矫正

    v = math.sqrt(gps.vel_e ** 2 + gps.vel_n ** 2)

    return de, dn, heading


def pos_tf(de0, dn0, heading0, de, dn, heading):
    # l = 0.824 + 0.64  # GPS后天线到前轴中心纵向距离
    # w = 0.545  # GPS后天线到前轴中心横向距离
    l = 0  # GPS后天线到前轴中心纵向距离
    w = 0  # GPS后天线到前轴中心横向距离

    thetaf = heading - heading0

    de00 = de0 + w * sin(heading0) + l * cos(heading0)
    dn00 = dn0 - w * cos(heading0) + l * sin(heading0)

    dee = de + w * sin(heading) + l * cos(heading)
    dnn = dn - w * cos(heading) + l * sin(heading)

    xf = (dee - de00) * cos(heading0) + (dnn - dn00) * sin(heading0)
    yf = -(dee - de00) * sin(heading0) + (dnn - dn00) * cos(heading0)
    return xf, yf, thetaf
