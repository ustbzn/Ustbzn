#!/usr/bin/env python3
# -- coding:UTF-8 --

import math
import numpy as np


def get_path(pos, Np, T, v_ref, n_states):
    """
    Straight line
    """
    # r = 0.1
    # pi = 3.14
    #
    # L1 = 300
    #
    # l1 = int(L1 / r / T)
    #
    # X = np.zeros((4, l1))
    #
    # for i in range(l1):
    #     X[0, i] = i * r * T
    #     X[1, i] = i * 0
    #     X[2, i] = 0
    #     X[3, i] = 0

    """
    Single line change
    """
    r = 0.1
    pi = 3.14

    L1 = 10
    R1 = 8
    L2 = 0
    R2 = 8
    L3 = 100

    l1 = int(L1 / r / T)
    l2 = int(l1 + 2 * pi * R1 / 8 / r / T)
    l3 = int(l2 + L2 / r / T)
    l4 = int(l3 + 2 * pi * R2 / 8 / r / T)
    l5 = int(l4 + L3 / r / T)

    sum = l5

    X = np.zeros((4, l5))

    for i in range(l5):
        if i < l1:
            X[0, i] = i * r * T
            X[1, i] = i * 0
            X[2, i] = 0
            X[3, i] = 0
        elif l1 <= i < l2:
            X[0, i] = L1 + R1 * math.sin((i - l1) * r * T / R1)
            X[1, i] = R1 - R1 * math.cos((i - l1) * r * T / R1)
            X[2, i] = 0 + (i - l1) * r * T / R1
            X[3, i] = 0
        elif l2 <= i < l3:
            X[0, i] = L1 + (R1 / math.sqrt(2)) + (i - l2) * r * T / math.sqrt(2)
            X[1, i] = (R1 - R1 / math.sqrt(2)) + (i - l2) * r * T / math.sqrt(2)
            X[2, i] = pi / 4
            X[3, i] = 0
        elif l3 <= i < l4:
            X[0, i] = L1 + (R1 / math.sqrt(2)) + (L2 / math.sqrt(2)) + (R2 / math.sqrt(2)) - R2 * math.cos(
               (i - l3) * r * T / R2 + pi / 4)
            X[1, i] = (R1 - R1 / math.sqrt(2)) + (L2 / math.sqrt(2)) - R2 / math.sqrt(2) + R2 * math.sin(
              (i - l3) * r * T / R2 + pi / 4)
            X[2, i] = (1 / 4) * pi - (i - l3) * r * T / R2
            X[3, i] = 0
        else:
            X[0, i] = L1 + (R1 / math.sqrt(2)) + (L2 / math.sqrt(2)) + (R2 / math.sqrt(2)) + (i - l4) * r * T
            X[1, i] = (R1 - R1 / math.sqrt(2)) + (L2 / math.sqrt(2)) + (R2 - R2 / math.sqrt(2)) + (i - l4) * 0
            X[2, i] = 0
            X[3, i] = 0

    """
    Circle R = 5 m
    """
    """
    r = 0.1
    pi = 3.14

    L1 = 10
    R1 = 5

    laps = 5

    l1 = int(L1 / r / T)
    l2 = int(l1 + 2 * pi * R1 * laps / r / T)

    sum = l5

    X = np.zeros((4, l2))

    for i in range(l2):
        if i < l1:
            X[0, i] = i * r * T
            X[1, i] = i * 0
            X[2, i] = 0
            X[3, i] = 0
        else:
            X[0, i] = L1 + R1 * math.sin((i - l1) * r * T / R1)
            X[1, i] = R1 - R1 * math.cos((i - l1) * r * T / R1)
            X[2, i] = 0 + (i - l1) * r * T / R1
            X[3, i] = 0
    """

    # """
    # Turn left
    # """
    #
    # r = 0.1
    # pi = 3.14
    #
    # L1 = 10
    # R1 = 50
    # L2 = 50
    #
    # l1 = int(L1 / r / T)
    # l2 = int(l1 + 2 * pi * R1 / 4 / r / T)
    # l3 = int(l2 + L2 / r / T)
    #
    # X = np.zeros((4, l3))
    #
    # for i in range(l3):
    #     if i < l1:
    #         X[0, i] = i * r * T
    #         X[1, i] = 0
    #         X[2, i] = 0
    #         X[3, i] = 0
    #     elif l1 <= i < l2:
    #         X[0, i] = L1 + R1 * math.sin((i - l1) * r * T / R1)
    #         X[1, i] = R1 - R1 * math.cos((i - l1) * r * T / R1)
    #         X[2, i] = 0 + (i - l1) * r * T / R1
    #         X[3, i] = 0
    #     elif l2 <= i < l3:
    #         X[0, i] = L1 + R1
    #         X[1, i] = R1 + (i - l2) * r * T
    #         X[2, i] = pi / 2
    #         X[3, i] = 0

    # # Three circles
    # # 每次循环中参考路径的选取
    # r = 0.1  # 参考路径的速度分辨率
    # pi = 3.14
    #
    # # 定义各段路径参数
    # # 三圆路径
    # l1 = 30  # 第一段直线距离
    # r1 = 30  # 第一个圆的半径（1/4圆）
    # r2 = 25  # 第二个圆的半径（1/2圆）
    # r3 = 20  # 第三个圆的半径（1/4圆）
    # l2 = 200  # 最后段直线距离
    #
    # # 计算每段路径在速度分辨率下应有多少个点
    # # （例如参考路径为1m, 速度分辨率为0.1m/s，时间间隔为0.05s，则每0.05s应走0.05s * 0.1m/s=0.005m，路径总长1m，则应有1m/0.005m=200个点）
    # lim1 = int(l1 / r / T)
    # lim2 = int((l1 + 2 * pi * r1 / 4) / r / T)
    # lim3 = int((l1 + 2 * pi * r1 / 4 + 2 * pi * r2 / 2) / r / T)
    # lim4 = int((l1 + 2 * pi * r1 / 4 + 2 * pi * r2 / 2 + 2 * pi * r3 / 4) / r / T)
    # lim5 = int((l1 + 2 * pi * r1 / 4 + 2 * pi * r2 / 2 + 2 * pi * r3 / 4 + l2) / r / T)
    #
    # X = np.zeros((4, lim5))  # 创建存储整段参考路径的矩阵
    #
    # for i in range(lim5):
    #     if i < lim1:
    #         X[0, i] = i * r * T
    #         X[1, i] = i * 0
    #         X[2, i] = 0
    #         X[3, i] = 0
    #     elif lim1 <= i < lim2:
    #         X[0, i] = l1 + r1 * sin((i - lim1) * r * T / r1)
    #         X[1, i] = r1 - r1 * cos((i - lim1) * r * T / r1)
    #         X[2, i] = 0 + (i - lim1) * r * T / r1
    #         X[3, i] = 0
    #     elif lim2 <= i < lim3:
    #         X[0, i] = l1 + r1 + r2 - r2 * cos((i - lim2) * r * T / r2)
    #         X[1, i] = r1 + r2 * sin((i - lim2) * r * T / r2)
    #         X[2, i] = pi / 2 - (i - lim2) * T * r / r2
    #         X[3, i] = 0
    #     elif lim3 <= (i - 1) < lim4:
    #         X[0, i] = l1 + r1 + r2 * 2 + r3 - r3 * cos((i - lim3) * r * T / r3)
    #         X[1, i] = r1 + r2 - r2 - r3 * sin((i - lim3) * r * T / r3)
    #         X[2, i] = -pi / 2 + (i - lim3) * r * T / r3
    #         X[3, i] = 0
    #     else:
    #         X[0, i] = l1 + r1 + r2 * 2 + r3 + (i - lim4) * r * T
    #         X[1, i] = r1 - r3 + (i - lim4) * 0
    #         X[2, i] = 0
    #         X[3, i] = 0

    xf, yf, thetaf = pos[0], pos[1], pos[2]

    dis_min = 1000000
    count = 0

    for j in range(np.size(X, 1)):
        dis = math.sqrt((xf - X[0, j]) ** 2 + (yf - X[1, j]) ** 2)
        if dis < dis_min:
            dis_min = dis
            count = j

    # print("shortest distance:", dis_min)

    x1, y1 = X[0, count], X[1, count]

    dx = x1 - xf
    dy = y1 - yf
    distance = math.sqrt(dx * dx + dy * dy)
    rota = math.asin(dy/(distance + 0.0001))

    if y1 - yf > 0:
        if xf < x1:
            rota = rota
        else:
            rota = math.pi - rota
    else:
        if xf < x1:
            rota = - math.pi - rota
        else:
            rota = rota

    if thetaf - rota > math.pi / 2 or thetaf - rota < -math.pi / 2:
        count = count + 1
    # print(X[0, count], X[1, count])
    vkey = int(v_ref / r)  # 计算不同的参考速度下中间需要隔过多少个点

    X_ref = np.zeros((Np, n_states))  # 创建存储该次循环中参考路径的矩阵

    if count >= sum:
        count = sum

    for j in range(count, count + Np):
        if count <= sum - 1 - Np:
            X_ref[j - count, 0] = X[0, j + vkey * (j - count)]
            X_ref[j - count, 1] = X[1, j + vkey * (j - count)]
            X_ref[j - count, 2] = X[2, j + vkey * (j - count)]
            X_ref[j - count, 3] = X[3, j + vkey * (j - count)]
        else:
            if j <= sum - 1:
                X_ref[j - count, 0] = X[0, j]
                X_ref[j - count, 1] = X[1, j]
                X_ref[j - count, 2] = X[2, j]
                X_ref[j - count, 3] = X[3, j]
            else:
                X_ref[j - count, 0] = X[0, l1 - 1]
                X_ref[j - count, 1] = X[1, l1 - 1]
                X_ref[j - count, 2] = X[2, l1 - 1]
                X_ref[j - count, 3] = X[3, l1 - 1]
    # print(X_ref[0, 0], X_ref[0, 1])
    return X_ref
